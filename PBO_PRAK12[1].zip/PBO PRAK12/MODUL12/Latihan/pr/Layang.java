/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sartika
 */

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Layang extends JFrame {

    final JTextField diagonal1Txt = new JTextField(10);
    final JTextField diagonal2Txt = new JTextField(10);
    final JTextField hasilTxt = new JTextField(10);
    JLabel diagonal1 = new JLabel("Diagonal 1 ");
    JLabel diagonal2 = new JLabel("Diagonal 2 ");
    JLabel hasil = new JLabel("Hasilnya ");
    JButton hitungLuas = new JButton("Hitung Luas");

    public Layang() {
        setTitle("Luas Layang-Layang");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(255, 200);

        setLayout(null);
        add(diagonal1);
        add(diagonal2);
        add(hasil);
        add(hasilTxt);
        add(diagonal1Txt);
        add(diagonal2Txt);
        add(hitungLuas);

        diagonal1.setBounds(10, 10, 80, 20);
        diagonal2.setBounds(10, 40, 80, 20);
        hasil.setBounds(10, 70, 80, 20);
        diagonal1Txt.setBounds(80, 10, 150, 20);
        diagonal2Txt.setBounds(80, 40, 150, 20);
        hasilTxt.setBounds(80, 70, 150, 20);
        hitungLuas.setBounds(80, 100, 120, 20);

        hasilTxt.setEditable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        hitungLuas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (diagonal1Txt.getText().equals("") || diagonal2Txt.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Semua field tidak boleh kosong");
                } else {
                    try {
                        double d1 = Integer.parseInt(diagonal1Txt.getText());
                        double d2 = Integer.parseInt(diagonal2Txt.getText());

                        hasilTxt.setText(String.valueOf((d1 * d2) / 2));

                    } catch (Exception er) {
                        JOptionPane.showMessageDialog(null, "Input harus berupa numerik");
                    }
                }
            }
        });
    }
}
