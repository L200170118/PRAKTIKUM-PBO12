/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sartika
 */

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JajaranGenjang extends JFrame {

    final JTextField alasTxt = new JTextField(10);
    final JTextField tinggiTxt = new JTextField(10);
    final JTextField hasilTxt = new JTextField(10);
    JLabel alas = new JLabel("Alas ");
    JLabel tinggi = new JLabel("Tinggi ");
    JLabel hasil = new JLabel("Hasilnya ");
    JButton hitungLuas = new JButton("Hitung Luas");

    public JajaranGenjang() {
        setTitle("Luas Jajar Genjang");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(255, 200);

        setLayout(null);
        add(alas);
        add(tinggi);
        add(hasil);
        add(hasilTxt);
        add(alasTxt);
        add(tinggiTxt);
        add(hitungLuas);

        alas.setBounds(10, 10, 80, 20);
        tinggi.setBounds(10, 40, 80, 20);
        hasil.setBounds(10, 70, 80, 20);
        alasTxt.setBounds(80, 10, 150, 20);
        tinggiTxt.setBounds(80, 40, 150, 20);
        hasilTxt.setBounds(80, 70, 150, 20);
        hitungLuas.setBounds(80, 100, 120, 20);

        hasilTxt.setEditable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        hitungLuas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (alasTxt.getText().equals("") || tinggiTxt.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Semua field tidak boleh kosong");
                } else {
                    try {
                        double mAlas = Integer.parseInt(alasTxt.getText());
                        double mTinggi = Integer.parseInt(tinggiTxt.getText());

                        hasilTxt.setText(String.valueOf(mAlas * mTinggi));

                    } catch (Exception er) {
                        JOptionPane.showMessageDialog(null, "Input harus berupa numerik");
                    }
                }
            }
        });
    }
}
