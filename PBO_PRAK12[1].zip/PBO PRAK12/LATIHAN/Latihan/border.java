/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;
/**
 *
 * @author sartika
 */
import java.awt.*;
import javax.swing.*;
public class border extends JPanel{
    public border(){
        setLayout (new BorderLayout());
        setBackground (Color.white);
        JLabel b1 = new JLabel ("Timur");
        b1.setBackground(Color.red);
        b1.setOpaque(true);
        
        JLabel b2 = new JLabel ("barat");
        b2.setBackground(Color.BLUE);
        b2.setOpaque(true);
        
        JLabel b3 = new JLabel ("Utara");
        b3.setBackground(Color.GREEN);
        b3.setOpaque(true);
        
        JLabel b4 = new JLabel ("Selatan");
        b4.setBackground(Color.YELLOW);
        b4.setOpaque(true);
        
        JLabel b5 = new JLabel ("Pusat");
        b5.setBackground(Color.ORANGE);
        b5.setOpaque(true);
        
        add (b1, BorderLayout.WEST);
        add (b2, BorderLayout.SOUTH);
        add (b3, BorderLayout.NORTH);
        add (b4, BorderLayout.EAST);
        add (b5, BorderLayout.CENTER);
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame ("Tugas Dengan Flow Layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        border b = new border();
        frame.setSize(800, 400);
        
        frame.getContentPane().add(b);
        frame.pack();
        frame.setVisible(true);
    }
}

