/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;
/**
 *
 * @author sartika
 */
import java.awt.*;
import javax.swing.*;
public class grid extends JPanel{
    public grid(){
        setLayout (new GridLayout(2, 3, 5 ,10));
        setBackground (Color.white);
        JLabel b1 = new JLabel ("Timur");
        b1.setBackground(Color.red);
        b1.setOpaque(true);
        
        JLabel b2 = new JLabel ("barat");
        b2.setBackground(Color.BLUE);
        b2.setOpaque(true);
        
        JLabel b3 = new JLabel ("Utara");
        b3.setBackground(Color.GREEN);
        b3.setOpaque(true);
        
        JLabel b4 = new JLabel ("Selatan");
        b4.setBackground(Color.YELLOW);
        b4.setOpaque(true);
        
        JLabel b5 = new JLabel ("Pusat");
        b5.setBackground(Color.ORANGE);
        b5.setOpaque(true);
        
        add (b1);
        add (b2);
        add (b3);
        add (b4);
        add (b5);
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame ("Tugas Dengan Flow Layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        grid g = new grid();
        frame.setSize(800, 400);
        
        frame.getContentPane().add(g);
        frame.pack();
        frame.setVisible(true);
    }
}

