/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author sartika
 */
public class IntroPanel extends JPanel
{
    public IntroPanel(JLabel JLabel)
    {
        setBackground (Color.green);
        
        JLabel = new JLabel ("Tampilan layout untuk GUI");
        JLabel = new JLabel ("Pilih tiap tab untuk melihat karakteristiknya");
        
        add (11);
        add (12);
    }
}

